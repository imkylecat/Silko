globalThis.__PYON_LOADER__ = {
    loaderName: "BTLoader",
    loaderVersion: "1.0.2",
    hasThemeSupport: true,
    storedTheme: null,
    fontPatch: 2
} 